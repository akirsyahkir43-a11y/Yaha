const screen=document.getElementById('screen');
const programs=[
 ['🏆','GAH Awards','Global Agensi Halu Awards'],
 ['⚗','V:LAB','Creative studio & music production'],
 ['✦','NXT GENERATION','New trainee & idol program'],
 ['♫','V-SYNC','Live performances & music sessions'],
 ['◎','ID:ONE','Artist profiles & stories'],
 ['◇','V-MODE','Fashion & styling'],
 ['▶','V-LOGUE','Documentary & behind the scenes'],
 ['∞','UN:ITY','International collaborations'],
 ['★','V-CLUB','Fandom community'],
 ['▥','V-CHART','Rankings & charts']
];
function card(p){return `<article class="program-card"><span class="symbol">${p[0]}</span><b>${p[1]}</b><small>${p[2]}</small></article>`}
function home(){return `<div class="eyebrow">Welcome to</div><h1 class="page-title">Y-VERS</h1><p class="sub">K-POP · ENTERTAINMENT · BEYOND</p>
<section class="hero"><div><div class="eyebrow">The biggest award in Y-VERS</div><h2>GAH AWARDS</h2><p>Dukung pilihanmu. Voting gratis.</p><button class="btn" onclick="navigate('gah')">Lihat GAH Awards →</button></div><div class="trophy">🏆</div></section>
<div class="section-head"><h3>Program Y-VERS</h3><span class="muted">10 program</span></div><div class="grid">${programs.map(card).join('')}</div>
<div class="section-head"><h3>Video Terbaru</h3><span class="muted">Segera hadir</span></div><div class="video-card"><div class="video-art">▶</div><div class="video-info"><b>Video resmi Y-VERS</b><p class="muted">Video akan muncul di sini setelah fitur upload diaktifkan.</p></div></div>
<div class="notice">📢 <b>Pengumuman Y-VERS</b><br><span class="muted">Pengumuman resmi akan tampil di halaman ini.</span></div>`}
function programPage(){return `<div class="eyebrow">Explore all shows</div><h1 class="page-title">Program</h1><p class="sub">10 Program, Satu Dunia Hiburan!</p><div class="tabs"><button class="tab selected">Semua</button><button class="tab">Music</button><button class="tab">Entertainment</button><button class="tab">Special</button></div><div class="grid">${programs.map(card).join('')}</div>`}
function gah(){return `<div class="eyebrow">Y-VERS presents</div><h1 class="page-title">🏆 GAH Awards</h1><p class="sub">Global Agensi Halu Awards</p><section class="hero"><div><h2>GAH AWARDS</h2><p>Celebrate talent. Share the spotlight.</p><span class="muted">Voting belum dibuka.</span></div><div class="trophy">🏆</div></section><div class="tabs"><button class="tab selected">Beranda</button><button class="tab" onclick="toast('Nominasi akan tersedia setelah diumumkan.')">Nominasi</button><button class="tab" onclick="toast('Hasil voting belum tersedia.')">Hasil Voting</button><button class="tab" onclick="toast('Informasi acara segera hadir.')">Acara</button></div><div class="panel"><h3>Cara Voting</h3><p class="muted">1. Masuk ke akun Y-VERS<br>2. Pilih kategori dan nominasi<br>3. Kirim pilihan saat voting resmi dibuka.</p><b style="color:#c99aff">Voting GAH Awards direncanakan gratis.</b></div><div class="notice">📣 Informasi nominasi dan jadwal resmi akan diumumkan di sini.</div>`}
function community(){return `<div class="eyebrow">Connect with fans</div><h1 class="page-title">Community</h1><p class="sub">Bergabung, berbagi, dan terhubung dengan komunitas Y-VERS.</p><div class="panel"><b>Buat postingan</b><textarea class="field" rows="3" placeholder="Apa yang ingin kamu bagikan?" id="postText"></textarea><button class="btn" onclick="addPost()">Posting</button><p class="muted">Postingan demo hanya tersimpan sementara di halaman ini.</p></div><div id="posts"><article class="post"><b>Y-VERS Official</b><p>Selamat datang di Community Y-VERS! ✨</p><div class="post-actions"><span>♡ Suka</span><span>◯ Komentar</span><span>↗ Bagikan</span></div></article></div>`}
function profile(){return `<div class="eyebrow">Your account</div><h1 class="page-title">My Profile</h1><div class="profile-head"><div class="avatar">Y</div><div><h2 style="margin:0">Pengguna Y-VERS</h2><span class="muted">@username</span><p class="muted">Dream Big, Be a Star ✨</p></div></div><div class="stats"><div><b>0</b><small>Postingan</small></div><div><b>0</b><small>Pengikut</small></div><div><b>0</b><small>Mengikuti</small></div></div><div class="panel"><h3>Akun</h3><p>✎ Edit Profil</p><p>☆ Achievement</p><p>🏆 Riwayat Voting GAH Awards</p><p>⚙ Pengaturan</p><p class="muted">Login dan sinkronisasi akun akan dihubungkan pada tahap backend.</p></div>`}
const pages={home,program:programPage,gah,community,profile};
function navigate(page){screen.innerHTML=pages[page]();document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===page));window.scrollTo(0,0)}
document.querySelectorAll('.bottom-nav button').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.page)));
function toast(message){const el=document.getElementById('toast');el.textContent=message;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2200)}
function addPost(){const input=document.getElementById('postText');const value=input.value.trim();if(!value){toast('Tulis sesuatu terlebih dahulu.');return}const article=document.createElement('article');article.className='post';article.innerHTML=`<b>Pengguna Y-VERS</b><p></p><div class="post-actions"><span>♡ Suka</span><span>◯ Komentar</span><span>↗ Bagikan</span></div>`;article.querySelector('p').textContent=value;document.getElementById('posts').prepend(article);input.value='';toast('Postingan demo ditambahkan.')}
navigate('home');
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}))}
